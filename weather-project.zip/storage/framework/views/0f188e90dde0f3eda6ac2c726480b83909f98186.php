<?php $__env->startSection('content'); ?>

<div class="hero" data-bg-image="<?php echo e(asset('client/images/banner.png')); ?>">
    <div class="container">
        <form action="/" class="find-location" id="header-search" autocomplete="off">
            <input autocomplete="off" type="text" class="search-input" name="search" placeholder="Find your location...">
            <!-- <input type="submit" value="Find"> -->
            <div id="result">
            </div>
        </form>
    </div>
</div>
<div class="forecast-table">
    <div class="container main-daily">
        <div class="forecast-container">
            <?php $__currentLoopData = $weathers_daily; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $daily): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <!-- TODO: print current  -->
            <?php if($key == 0): ?>

            <div class="today forecast">
                <div class="forecast-header">
                    <div class="day"><?php echo e(getWeekday($daily->datetime)); ?></div>
                    <div class="date"><?php echo e($daily->datetime); ?></div>
                </div> <!-- .forecast-header -->
                <div class="forecast-content">
                    <div class="isToday">
                        <div class="location">Ha Noi</div>
                        <div class="degree">
                            <div class="num"><?php echo e($daily->temp); ?><sup>o</sup>C</div>
                            <div class="forecast-icon">
                                <img src="<?php echo e(asset('client/images/icons/icon-1.svg')); ?>" alt="" width=90>
                            </div>
                        </div>
                        <span><img src="images/icon-umberella.png" alt=""><?php echo e($daily->rh); ?>%</span>
                        <span><img src="images/icon-wind.png" alt=""><?php echo e($daily->wind_dir); ?>km/h</span>
                        <!-- <span><img src="images/icon-compass.png" alt="">East</span> -->
                    </div>
                    <div class="notToday">
                        <div class="forecast-icon">
                            <img src="<?php echo e(asset('client/images/icons/icon-3.svg')); ?>" alt="" width=48>
                        </div>
                        <div class="degree"><?php echo e($daily->temp); ?><sup>o</sup>C</div>
                    </div>
                </div>
                <div class="hourly">
                    <?php $__currentLoopData = $daily->hourly; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keyHourly => $hourly): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="hourly-item"  data-toggle="modal" data-target="#hourly<?php echo e($hourly->id); ?>">
                            <div class="hourly-title">
                                <p><?php echo e($hourly->hour); ?></p>
                            </div>
                            <div class="hourly-content">
                                <h2><?php echo e($hourly->temp); ?><sup>o</sup>C</h2>
                            </div>
                            <div class="hourly-footer">
                                <img src="https://www.weatherbit.io/static/img/icons/<?php echo e($hourly->weather_json->icon); ?>.png" /></img>
                            </div>
                        </div>

                        <!-- The Modal -->
                        <div class="modal" id="hourly<?php echo e($hourly->id); ?>" style="color: #000">
                            <div class="modal-dialog">
                                <div class="modal-content">

                                <!-- Modal Header -->
                                <div class="modal-header">
                                    <h4 class="modal-title">Giờ: <?php echo e($hourly->hour); ?></h4>
                                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                                </div>

                                <!-- Modal body -->
                                <div class="modal-body">

                                    <img src="https://www.weatherbit.io/static/img/icons/<?php echo e($hourly->weather_json->icon); ?>.png" /></img>
                                    <p>Độ ẩm tương đối: <?php echo e($hourly->rh); ?>%</p>
                                    <p>Tốc độ gió: <?php echo e($hourly->wind_spd); ?>m/s</p>
                                    <p>Áp suất: <?php echo e($hourly->press); ?></p>
                                    <p>Tầm nhìn xa: <?php echo e($hourly->vis); ?>km</p>
                                    <p>Mực nước biển: <?php echo e($hourly->slp); ?>mb</p>
                                    <p>Thời điểm: <?php echo e($hourly->pod == "d"  ? 'Ngày' : 'Đêm'); ?></p>
                                    <p>Điểm sương: <?php echo e($hourly->dewpt); ?> C</p>
                                    <p>Hướng gió: <?php echo e($hourly->wind_dir); ?> độ</p>
                                    <p>Nhiệt độ: <?php echo e($hourly->temp); ?> C</p>
                                    <p>Lượng mây: <?php echo e($hourly->clouds); ?> %</p>
                                </div>

                                <!-- Modal footer -->
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                                </div>

                                </div>
                            </div>
                        </div>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

            <?php else: ?>
            <div class="forecast">
                <div class="forecast-header">
                    <div class="day"><?php echo e(getWeekday($daily->datetime)); ?></div>
                    <div class="date"><?php echo e($daily->datetime); ?></div>
                </div> <!-- .forecast-header -->
                <div class="forecast-content">
                    <div class="isToday">
                        <div class="location">Ha Noi</div>
                        <div class="degree">
                            <div class="num"><?php echo e($daily->temp); ?><sup>o</sup>C</div>
                            <div class="forecast-icon">
                                <img src="<?php echo e(asset('client/images/icons/icon-1.svg')); ?>" alt="" width=90>
                            </div>
                        </div>
                        <span><img src="images/icon-umberella.png" alt=""><?php echo e($daily->rh); ?>%</span>
                        <span><img src="images/icon-wind.png" alt=""><?php echo e($daily->wind_dir); ?>km/h</span>
                        <!-- <span><img src="images/icon-compass.png" alt="">East</span> -->
                    </div>
                    <div class="notToday">
                        <div class="forecast-icon">
                            <img src="<?php echo e(asset('client/images/icons/icon-3.svg')); ?>" alt="" width=48>
                        </div>
                        <div class="degree"><?php echo e($daily->temp); ?><sup>o</sup>C</div>
                    </div>
                </div>
                <div class="hourly">
                    <?php $__currentLoopData = $daily->hourly; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hourly): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="hourly-item"  data-toggle="modal" data-target="#hourly<?php echo e($hourly->id); ?>">
                            <div class="hourly-title">
                                <p><?php echo e($hourly->hour); ?></p>
                            </div>
                            <div class="hourly-content">
                                <h2><?php echo e($hourly->temp); ?><sup>o</sup>C</h2>
                            </div>
                            <div class="hourly-footer">
                                <img src="https://www.weatherbit.io/static/img/icons/<?php echo e($hourly->weather_json->icon); ?>.png" /></img>
                            </div>
                        </div>

                        <!-- The Modal -->
                        <div class="modal" id="hourly<?php echo e($hourly->id); ?>" style="color: #000">
                            <div class="modal-dialog">
                                <div class="modal-content">

                                <!-- Modal Header -->
                                <div class="modal-header">
                                    <h4 class="modal-title">Giờ: <?php echo e($hourly->hour); ?></h4>
                                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                                </div>

                                <!-- Modal body -->
                                <div class="modal-body">

                                    <img src="https://www.weatherbit.io/static/img/icons/<?php echo e($hourly->weather_json->icon); ?>.png" /></img>
                                    <p>Độ ẩm tương đối: <?php echo e($hourly->rh); ?>%</p>
                                    <p>Tốc độ gió: <?php echo e($hourly->wind_spd); ?>m/s</p>
                                    <p>Áp suất: <?php echo e($hourly->press); ?></p>
                                    <p>Tầm nhìn xa: <?php echo e($hourly->vis); ?>km</p>
                                    <p>Mực nước biển: <?php echo e($hourly->slp); ?>mb</p>
                                    <p>Thời điểm: <?php echo e($hourly->pod == "d"  ? 'Ngày' : 'Đêm'); ?></p>
                                    <p>Điểm sương: <?php echo e($hourly->dewpt); ?> C</p>
                                    <p>Hướng gió: <?php echo e($hourly->wind_dir); ?> độ</p>
                                    <p>Nhiệt độ: <?php echo e($hourly->temp); ?> C</p>
                                    <p>Lượng mây: <?php echo e($hourly->clouds); ?> %</p>
                                </div>

                                <!-- Modal footer -->
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                                </div>

                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <?php endif; ?>



            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

    </div>
</div>
<main class="main-content">
    <br>
    <table width="85%" align="center" cellpadding="0" cellspacing="0" border="0">
        <tbody>
            <tr>
                <td colspan="3" align="left">
                    <table border="0" cellpadding="0" cellspacing="0" width="99%">
                        <tbody>
                            <tr>
                                <td class="bgr_LeftHeader"></td>
                                <td class="bgr_ContentHeader box_Title"> <span id="_ctl1__ctl4__ctl0_lbl_Bantindubao">Dự
                                        báo thời tiết - </span>Ngày và đêm 30/10/2019
                                    <!--23/09/2019-->
                                </td>
                                <td class="bgr_RightHeader"></td>
                                <td class="bgr_TopBox" width="45%"></td>
                            </tr>
                        </tbody>
                    </table>
                </td>
            </tr>
            <tr>
                <td width="1" class="bgr_vertical"></td>
                <td width="98%" align="left">
                    <!-- BEGIN DISPLAY DATA HERE -->
                    <div style="CLEAR: both;OVERFLOW-Y: scroll;DISPLAY: block;WIDTH: 100%;HEIGHT: 250px"
                        class="BantinThuyvan_div">
                        <table id="_ctl1__ctl4__ctl0_dl_Bantindubao" cellspacing="0" border="0" width="96%">
                            <tbody>
                                <tr>
                                    <td>
                                        <table cellspacing="2" cellpadding="2" border="0" class="dl_Bantindubao"
                                            width="100%">
                                            <tbody>
                                                <tr>
                                                    <td align="left">
                                                        <table border="0" cellpadding="2" cellspacing="2" width="100%">
                                                            <tbody>
                                                                <tr>
                                                                    <td colspan="2" class="btdb_Title"
                                                                        style="padding-left:2px" height="25px"
                                                                        bgcolor="">Phía Tây Bắc Bộ</td>
                                                                </tr>
                                                                <tr>
                                                                    <td width="25%" align="center">
                                                                        <img src="http://123.30.154.57/web/Upload/WeatherSymbol/2008/8/22/340.png"
                                                                            border="0">
                                                                    </td>
                                                                    <td valign="top">
                                                                        <span class="forecast_detail">Ít mây, ngày nắng,
                                                                            đêm không mưa, sáng sớm có nơi có sương mù.
                                                                            Gió nhẹ. Sáng sớm và đêm trời lạnh. Độ ẩm từ
                                                                            40-95%.</span><br>
                                                                        <span class="forecast_detail"><span
                                                                                id="_ctl1__ctl4__ctl0_dl_Bantindubao__ctl0_lbl_NhietDo_ThapNhat_Tu">Nhiệt
                                                                                độ thấp nhất từ :</span> : <strong>18 -
                                                                                21 độ, có nơi dưới
                                                                                16<sup>o</sup>C</strong></span><br>
                                                                        <span class="forecast_detail"><span
                                                                                id="_ctl1__ctl4__ctl0_dl_Bantindubao__ctl0_lbl_NhietDo_CaoNhat_Tu">Nhiệt
                                                                                độ cao nhất từ :</span> : <strong>29 -
                                                                                32<sup>o</sup>C</strong></span>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>

                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <table cellspacing="2" cellpadding="2" border="0" class="dl_Bantindubao"
                                            width="100%">
                                            <tbody>
                                                <tr>
                                                    <td align="left">
                                                        <table border="0" cellpadding="2" cellspacing="2" width="100%">
                                                            <tbody>
                                                                <tr>
                                                                    <td colspan="2" class="btdb_Title"
                                                                        style="padding-left:2px" height="25px">Phía Đông
                                                                        Bắc Bộ</td>
                                                                </tr>
                                                                <tr>
                                                                    <td width="25%" align="center">
                                                                        <img src="http://123.30.154.57/web/Upload/WeatherSymbol/2008/8/22/340.png"
                                                                            border="0">
                                                                    </td>
                                                                    <td valign="top">
                                                                        <span class="forecast_detail">Ít mây, ngày nắng,
                                                                            đêm không mưa, sáng sớm có sương mù và
                                                                            sương mù nhẹ rải rác. Gió đông bắc cấp
                                                                            2-3. Sáng sớm và đêm trời lạnh. Độ ẩm từ
                                                                            35-95%.</span><br>
                                                                        <span class="forecast_detail"><span
                                                                                id="_ctl1__ctl4__ctl0_dl_Bantindubao__ctl1_lbl_NhietDo_ThapNhat_Tu">Nhiệt
                                                                                độ thấp nhất từ :</span> : <strong>20 -
                                                                                23 độ, riêng vùng núi
                                                                                17-20<sup>o</sup>C</strong></span><br>
                                                                        <span class="forecast_detail"><span
                                                                                id="_ctl1__ctl4__ctl0_dl_Bantindubao__ctl1_lbl_NhietDo_CaoNhat_Tu">Nhiệt
                                                                                độ cao nhất từ :</span> : <strong>29 -
                                                                                32, có nơi trên
                                                                                32<sup>o</sup>C</strong></span>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>

                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <table cellspacing="2" cellpadding="2" border="0" class="dl_Bantindubao"
                                            width="100%">
                                            <tbody>
                                                <tr>

                                                    <td align="left">
                                                        <table border="0" cellpadding="2" cellspacing="2" width="100%">
                                                            <tbody>
                                                                <tr>
                                                                    <td colspan="2" class="btdb_Title"
                                                                        style="padding-left:2px" height="25px">Nam Bộ
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td width="25%" align="center">
                                                                        <img src="http://123.30.154.57/web/Upload/WeatherSymbol/2008/8/22/390.png"
                                                                            border="0">
                                                                    </td>
                                                                    <td valign="top">
                                                                        <span class="forecast_detail">Có mây, có mưa
                                                                            rào và dông vài nơi, riêng chiều tối và
                                                                            tối có mưa rào và dông rải rác. Gió
                                                                            nhẹ. Trong cơn dông có khả năng xảy ra lốc,
                                                                            sét và gió giật mạnh. Độ ẩm từ 65-98%.
                                                                        </span><br>
                                                                        <span class="forecast_detail"><span
                                                                                id="_ctl1__ctl4__ctl0_dl_Bantindubao__ctl5_lbl_NhietDo_ThapNhat_Tu">Nhiệt
                                                                                độ thấp nhất từ :</span> : <strong>23 -
                                                                                26<sup>o</sup>C</strong></span><br>
                                                                        <span class="forecast_detail"><span
                                                                                id="_ctl1__ctl4__ctl0_dl_Bantindubao__ctl5_lbl_NhietDo_CaoNhat_Tu">Nhiệt
                                                                                độ cao nhất từ :</span> : <strong>29 -
                                                                                32<sup>o</sup>C</strong></span>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>

                                                    </td>







                                                </tr>
                                            </tbody>
                                        </table>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <table cellspacing="2" cellpadding="2" border="0" class="dl_Bantindubao"
                                            width="100%">
                                            <tbody>
                                                <tr>
                                                    <td align="left">
                                                        <table border="0" cellpadding="2" cellspacing="2" width="100%">
                                                            <tbody>
                                                                <tr>
                                                                    <td colspan="2" class="btdb_Title"
                                                                        style="padding-left:2px" height="25px">Đà Nẵng
                                                                        đến Bình Thuận</td>
                                                                </tr>
                                                                <tr>
                                                                    <td width="25%" align="center">
                                                                        <img src="http://123.30.154.57/web/Upload/WeatherSymbol/2008/8/22/300.png"
                                                                            border="0">
                                                                    </td>
                                                                    <td valign="top">
                                                                        <span class="forecast_detail">Có mây, ngày nắng,
                                                                            chiều tối và đêm có mưa rào và dông vài nơi.
                                                                            Gió nhẹ. Trong cơn dông có khả năng xảy ra
                                                                            lốc, sét và gió giật mạnh. Gió nhẹ. Độ ẩm từ
                                                                            60-98%. </span><br>
                                                                        <span class="forecast_detail"><span
                                                                                id="_ctl1__ctl4__ctl0_dl_Bantindubao__ctl3_lbl_NhietDo_ThapNhat_Tu">Nhiệt
                                                                                độ thấp nhất từ :</span> : <strong>23 -
                                                                                26<sup>o</sup>C</strong></span><br>
                                                                        <span class="forecast_detail"><span
                                                                                id="_ctl1__ctl4__ctl0_dl_Bantindubao__ctl3_lbl_NhietDo_CaoNhat_Tu">Nhiệt
                                                                                độ cao nhất từ :</span> : <strong>29 -
                                                                                32 độ, có nơi trên
                                                                                32<sup>o</sup>C</strong></span>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>

                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <table cellspacing="2" cellpadding="2" border="0" class="dl_Bantindubao"
                                            width="100%">
                                            <tbody>
                                                <tr>
                                                    <td align="left">
                                                        <table border="0" cellpadding="2" cellspacing="2" width="100%">
                                                            <tbody>
                                                                <tr>
                                                                    <td colspan="2" class="btdb_Title"
                                                                        style="padding-left:2px" height="25px">Tây
                                                                        Nguyên</td>
                                                                </tr>
                                                                <tr>
                                                                    <td width="25%" align="center">
                                                                        <img src="http://123.30.154.57/web/Upload/WeatherSymbol/2008/8/22/390.png"
                                                                            border="0">
                                                                    </td>
                                                                    <td valign="top">
                                                                        <span class="forecast_detail">Có mây, có mưa
                                                                            rào và dông vài nơi, riêng chiều tối có mưa
                                                                            rào và dông rải rác. Gió nhẹ. Trong cơn dông
                                                                            có khả năng xảy ra lốc, sét và gió giật
                                                                            mạnh. Gió nhẹ. Độ ẩm từ 65-98%. </span><br>
                                                                        <span class="forecast_detail"><span
                                                                                id="_ctl1__ctl4__ctl0_dl_Bantindubao__ctl4_lbl_NhietDo_ThapNhat_Tu">Nhiệt
                                                                                độ thấp nhất từ :</span> : <strong>20 -
                                                                                23<sup>o</sup>C</strong></span><br>
                                                                        <span class="forecast_detail"><span
                                                                                id="_ctl1__ctl4__ctl0_dl_Bantindubao__ctl4_lbl_NhietDo_CaoNhat_Tu">Nhiệt
                                                                                độ cao nhất từ :</span> : <strong>27 -
                                                                                30 độ, có nơi trên
                                                                                30<sup>o</sup>C</strong></span>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>

                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </td>
                                </tr>
                                <tr>
                                    <td>


                                        **
                                        <table cellspacing="2" cellpadding="2" border="0" class="dl_Bantindubao"
                                            width="100%">
                                            <tbody>
                                                <tr>

                                                    <td align="left">
                                                        <table border="0" cellpadding="2" cellspacing="2" width="100%">
                                                            <tbody>
                                                                <tr>
                                                                    <td colspan="2" class="btdb_Title"
                                                                        style="padding-left:2px" height="25px">Thanh Hóa
                                                                        - Thừa Thiên Huế</td>
                                                                </tr>
                                                                <tr>
                                                                    <td width="25%" align="center">
                                                                        <img src="http://123.30.154.57/web/Upload/WeatherSymbol/2008/8/22/300.png"
                                                                            border="0">
                                                                    </td>
                                                                    <td valign="top">
                                                                        <span class="forecast_detail">Có mây, ngày nắng,
                                                                            chiều tối và đêm có mưa rào và dông vài
                                                                            nơi. Gió nhẹ. Độ ẩm từ 50-95%.</span><br>
                                                                        <span class="forecast_detail"><span
                                                                                id="_ctl1__ctl4__ctl0_dl_Bantindubao__ctl2_lbl_NhietDo_ThapNhat_Tu">Nhiệt
                                                                                độ thấp nhất từ :</span> : <strong>22 -
                                                                                25<sup>o</sup>C</strong></span><br>
                                                                        <span class="forecast_detail"><span
                                                                                id="_ctl1__ctl4__ctl0_dl_Bantindubao__ctl2_lbl_NhietDo_CaoNhat_Tu">Nhiệt
                                                                                độ cao nhất từ :</span> : <strong>29 -
                                                                                32<sup>o</sup>C</strong></span>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>

                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <table cellspacing="2" cellpadding="2" border="0" class="dl_Bantindubao"
                                            width="100%">
                                            <tbody>
                                                <tr>
                                                    <td align="left">
                                                        <table border="0" cellpadding="2" cellspacing="2" width="100%">
                                                            <tbody>
                                                                <tr>
                                                                    <td colspan="2" class="btdb_Title"
                                                                        style="padding-left:2px" height="25px">Hà Nội
                                                                    </td>
                                                                </tr>
                                                                <tr>
                                                                    <td width="25%" align="center">
                                                                        <img src="http://123.30.154.57/web/Upload/WeatherSymbol/icon_resized/1001.png"
                                                                            border="0">
                                                                    </td>
                                                                    <td valign="top">
                                                                        <span class="forecast_detail">Ít mây, ngày nắng,
                                                                            đêm không mưa, sáng sớm có sương mù và
                                                                            sương mù nhẹ rải rác. Gió đông bắc cấp
                                                                            2-3. Sáng sớm và đêm trời lạnh. Độ ẩm từ
                                                                            35-88%.</span><br>
                                                                        <span class="forecast_detail"><span
                                                                                id="_ctl1__ctl4__ctl0_dl_Bantindubao__ctl6_lbl_NhietDo_ThapNhat_Tu">Nhiệt
                                                                                độ thấp nhất từ :</span> : <strong>20 -
                                                                                23<sup>o</sup>C</strong></span><br>
                                                                        <span class="forecast_detail"><span
                                                                                id="_ctl1__ctl4__ctl0_dl_Bantindubao__ctl6_lbl_NhietDo_CaoNhat_Tu">Nhiệt
                                                                                độ cao nhất từ :</span> : <strong>30-
                                                                                33<sup>o</sup>C</strong></span>
                                                                    </td>
                                                                </tr>
                                                            </tbody>
                                                        </table>

                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <!-- END DISPLAY DATA HERE -->
                </td>
                <td width="1" class="bgr_vertical"></td>
            </tr>
            <tr>
                <td class="box" colspan="3"></td>
            </tr>
        </tbody>
    </table>


</main>
<?php $__env->stopSection(); ?>

<?php $__env->startPush("scripts"); ?>
<script type="text/javascript">
   $('#header-search').on('keyup', function() {
       var search = $(this).find('.search-input').val();
       if (search == '') {
        $("#result").hide()
       } else {
           axios.get('/search', {
               params: {
                search: search
               }
           })
           .then(res => {
               let html = "";
               res.data.result.forEach(e => {
                html += `<p>${e.name}</p>`;
               });
               console.log(html);
               $("#result").show();
               $("#result").html(html);

           }).catch(err => {
               console.log({err: err})
           });
       };
   });

   $(".forecast").click(function(e) {
       e.preventDefault();
       $('.forecast').removeClass('today');
    $(this).addClass("today");
   })
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('client.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\code\HuongDichVu\weather-project\resources\views/client/index.blade.php ENDPATH**/ ?>